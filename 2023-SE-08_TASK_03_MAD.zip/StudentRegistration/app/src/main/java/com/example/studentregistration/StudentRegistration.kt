package com.example.studentregistration

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.RadioButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistrationScreen() {
    // Text fields
    var fullName by rememberSaveable { mutableStateOf("") }
    var rollNo by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }

    // Selections ("" means nothing chosen yet)
    var programme by rememberSaveable { mutableStateOf("") }
    var studyMode by rememberSaveable { mutableStateOf("") }

    // Independent interests
    var mobileDev by rememberSaveable { mutableStateOf(false) }
    var webDev by rememberSaveable { mutableStateOf(false) }
    var testing by rememberSaveable { mutableStateOf(false) }

    // Switch and slider
    var updates by rememberSaveable { mutableStateOf(false) }
    var studyHours by rememberSaveable { mutableStateOf(0f) }

    // Dropdown open/closed
    var dropdownOpen by remember { mutableStateOf(false) }

    // Validation and success
    var submitted by rememberSaveable { mutableStateOf(false) }
    var success by rememberSaveable { mutableStateOf(false) }
    fun isValid(): Boolean =
        fullName.trim().isNotEmpty() &&
                rollNo.trim().isNotEmpty() &&
                email.trim().isNotEmpty() &&
                programme.isNotEmpty() &&
                studyMode.isNotEmpty()

    fun resetForm() {
        fullName = ""
        rollNo = ""
        email = ""
        programme = ""
        studyMode = ""
        mobileDev = false
        webDev = false
        testing = false
        updates = false
        studyHours = 0f
        submitted = false
        success = false
    }
    val nameError = submitted && fullName.trim().isEmpty()
    val rollError = submitted && rollNo.trim().isEmpty()
    val emailError = submitted && email.trim().isEmpty()
    val programmeError = submitted && programme.isEmpty()
    val modeError = submitted && studyMode.isEmpty()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Student Registration",
            style = MaterialTheme.typography.headlineMedium
        )

        OutlinedTextField(
            value = fullName,
            onValueChange = { fullName = it; success = false },
            label = { Text("Full name") },
            isError = nameError,
            supportingText = { if (nameError) Text("Full name is required") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = rollNo,
            onValueChange = { rollNo = it; success = false },
            label = { Text("Roll number") },
            isError = rollError,
            supportingText = { if (rollError) Text("Roll number is required") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = email,
            onValueChange = { email = it; success = false },
            label = { Text("Email") },
            isError = emailError,
            supportingText = { if (emailError) Text("Email is required") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        val programmes = listOf(
            "Software Engineering Technology",
            "Computer Science",
            "Information Technology"
        )

        ExposedDropdownMenuBox(
            expanded = dropdownOpen,
            onExpandedChange = { dropdownOpen = it }
        ) {
            OutlinedTextField(
                value = programme.ifEmpty { "Select programme" },
                onValueChange = {},
                readOnly = true,
                label = { Text("Programme") },
                isError = programmeError,
                supportingText = { if (programmeError) Text("Please select a programme") },
                trailingIcon = {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownOpen)
                },
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth()
            )
            ExposedDropdownMenu(
                expanded = dropdownOpen,
                onDismissRequest = { dropdownOpen = false }
            ) {
                programmes.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = {
                            programme = option
                            dropdownOpen = false
                            success = false
                        }
                    )
                }
            }
        }

        Text("Study mode", style = MaterialTheme.typography.titleMedium)

        listOf("On campus", "Online").forEach { mode ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .selectable(
                        selected = studyMode == mode,
                        onClick = { studyMode = mode; success = false },
                        role = Role.RadioButton
                    ),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = studyMode == mode, onClick = null)
                Spacer(Modifier.width(8.dp))
                Text(mode)
            }
        }
        if (modeError) {
            Text(
                text = "Please select a study mode",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }
        Text("Interests (optional)", style = MaterialTheme.typography.titleMedium)

        CheckRow("Mobile Development", mobileDev) { mobileDev = it; success = false }
        CheckRow("Web Development", webDev) { webDev = it; success = false }
        CheckRow("Software Testing", testing) { testing = it; success = false }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Receive course updates")
            Switch(
                checked = updates,
                onCheckedChange = { updates = it; success = false }
            )
        }

        Text(
            text = "Weekly study hours: ${studyHours.toInt()}",
            style = MaterialTheme.typography.titleMedium
        )
        Slider(
            value = studyHours,
            onValueChange = { studyHours = it; success = false },
            valueRange = 0f..20f,
            steps = 19
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = {
                submitted = true
                success = isValid()
            }) {
                Text("Register")
            }

            OutlinedButton(onClick = { resetForm() }) {
                Text("Reset")
            }
        }

        if (success) {
            Text(
                text = "Registration form completed successfully",
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}
@Composable
fun CheckRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .toggleable(
                value = checked,
                onValueChange = onChange,
                role = Role.Checkbox
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = null)
        Spacer(Modifier.width(8.dp))
        Text(label)
    }
}